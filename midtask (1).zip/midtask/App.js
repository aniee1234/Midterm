import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, FlatList, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

const Stack = createStackNavigator();

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    navigation.navigate('JobList');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.loginText}>Login</Text>
      <TextInput style={styles.input} placeholder="Email" value={email} onChangeText={setEmail} />
      <TextInput style={styles.input} placeholder="Password" secureTextEntry value={password} onChangeText={setPassword} />
      <Button title="Login" onPress={handleLogin} />
    </View>
  );
};

const JobListScreen = ({ navigation }) => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch('https://jsonfakery.com/job-posts')
      .then(response => response.json())
      .then(data => {
        console.log("API Response:", data); // Debugging: Check API response
        if (Array.isArray(data)) {
          setJobs(data);
        } else {
          throw new Error("Invalid API response format");
        }
      })
      .catch(error => {
        console.error("Fetch Error:", error);
        setError(error.message);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <ActivityIndicator size="large" color="#0000ff" />;
  if (error) return <Text>Error: {error}</Text>;

  return (
    <View style={styles.container}>
      <FlatList
        data={jobs}
        keyExtractor={item => item.id?.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => navigation.navigate('JobDetails', { job: item })}>
            <Text style={styles.jobTitle}>{item.title || `Job Title ${Math.floor(Math.random() * 100)}`}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

const JobDetailsScreen = ({ route }) => {
  const { job } = route.params || {};

  if (!job || Object.keys(job).length === 0) return <Text>No job details available.</Text>;

  return (
    <View style={styles.container}>
      <Text style={styles.jobTitle}>{job.title || `Random Job Title ${Math.floor(Math.random() * 100)}`}</Text>
      <Text>{job.description || "This is a randomly generated job description."}</Text>
      <Text>Requirements: {job.requirements || "Basic knowledge and willingness to learn."}</Text>
      <Text>Apply here: <Text style={{color: 'blue'}}>{job.application_link || "https://example.com/apply"}</Text></Text>
    </View>
  );
};


export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="JobList" component={JobListScreen} />
        <Stack.Screen name="JobDetails" component={JobDetailsScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: 'center', alignItems: 'center',backgroundColor:'teal', },
  input: { borderWidth: 1, marginBottom: 10, padding: 8, width: '80%' },
  jobTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 5 },
  loginText: { fontSize: 24, fontWeight: 'bold', marginBottom: 20, textAlign: 'center' },
});
